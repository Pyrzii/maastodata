# MaastoData — PWA Asennusohjeet

## Tiedostot
- `index.html` — sovellus
- `manifest.json` — PWA-asetukset
- `sw.js` — service worker (offline-tuki)
- `icon-192.png` / `icon-512.png` — sovelluksen ikoni

---

## Miten asennat Androidille

PWA vaatii, että tiedostot ovat saatavilla **https://-osoitteessa**.
Alla on kaksi ilmaista tapaa:

---

### Vaihtoehto A — Netlify Drop (helpoin, 2 minuuttia)

1. Mene osoitteeseen: **https://app.netlify.com/drop**
2. Raahaa koko `maastodata-pwa`-kansio sivulle
3. Netlify antaa sinulle osoitteen, esim. `https://random-name-123.netlify.app`
4. Avaa osoite Android-puhelimella **Chrome-selaimessa**
5. Chrome näyttää alareunassa bannerin: **"Lisää kotinäytölle"** — paina sitä
6. Sovellus asennetaan puhelimeen kuin mikä tahansa sovellus ✅

---

### Vaihtoehto B — GitHub Pages (ilmainen, pysyvä osoite)

1. Luo ilmainen tili: **https://github.com**
2. Luo uusi repository nimeltä `maastodata`
3. Lataa kaikki tiedostot repositoryyn
4. Mene Settings → Pages → Branch: main → Save
5. Osoitteesi: `https://kayttajanimi.github.io/maastodata`

---

## Asennus puhelimella (Chrome Android)

1. Avaa sovelluksen osoite Chrome-selaimessa
2. Odota hetki — banneri ilmestyy automaattisesti: **"Asenna MaastoData"**
3. Jos banneria ei tule: paina ⋮ (kolme pistettä) → "Lisää kotinäytölle"
4. Valmis! Sovellus toimii offline-tilassa ja tallentaa dataa puhelimeen.

---

## Offline-toiminta

Sovellus toimii ilman verkkoyhteyttä — karttatiilten lataaminen vaatii yhteyden,
mutta kaikki datansyöttö, laskenta ja tallennus toimivat offline.

---

## Tietojen siirto

Voit viedä kaiken datan CSV-tiedostona sovelluksen sisältä
(Yhteenveto → Lataa CSV tai Tallennetut kuviot → CSV).
